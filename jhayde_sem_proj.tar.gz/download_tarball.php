<?php

echo "<a href='jhayde_sem_proj.tar.gz' download>Download tarball</a><br><br>";

// Give user route to login page
echo "<a href='index.html'>Login Page</a>";

?>

