DELETE FROM user WHERE username = 'jhayde';
