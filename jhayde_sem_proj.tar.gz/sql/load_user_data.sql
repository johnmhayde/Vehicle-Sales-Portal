LOAD DATA LOCAL INFILE 'user_sample.txt' INTO TABLE user;
