SELECT * FROM vehicle WHERE model = 'Tacoma';
