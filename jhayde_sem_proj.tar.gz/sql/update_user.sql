UPDATE user SET password = 'new_pass' WHERE username = 'jhayde';
