SELECT * FROM vehicle WHERE make = 'Ford';
