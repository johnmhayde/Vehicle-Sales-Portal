INSERT INTO user VALUES ('jhayde', 'password', '123456789', 'John', 'Hayde', 21, 'jhayde@clemson.edu', '219 Cedar Creek Circle, Sunset, SC 29685');
