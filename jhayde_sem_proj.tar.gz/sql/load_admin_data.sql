LOAD DATA LOCAL INFILE 'admin_sample.txt' INTO TABLE admin;
