LOAD DATA LOCAL INFILE '../data/vehicles.txt' INTO TABLE vehicle;
