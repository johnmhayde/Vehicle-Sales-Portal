INSERT INTO user VALUES('$_POST[username]', '$_POST[password]', '$_POST[phone_num]', '$_POST[fname]', '$_POST[lname]', '$_POST[age]', '$_POST[email]', '$_POST[address]')
