SELECT * FROM vehicle;
