SELECT * FROM vehicle WHERE price < 10000;
