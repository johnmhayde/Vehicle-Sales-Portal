SELECT * FROM vehicle WHERE year > 2000;
