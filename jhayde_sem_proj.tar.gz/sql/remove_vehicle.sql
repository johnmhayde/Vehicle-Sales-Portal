DELETE FROM vehicle WHERE make = 'Ford' AND model = 'Edge';
