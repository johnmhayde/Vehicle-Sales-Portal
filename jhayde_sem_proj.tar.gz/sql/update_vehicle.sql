UPDATE vehicle SET price = 14000 WHERE make = 'Toyota' AND model = 'Tacoma';
